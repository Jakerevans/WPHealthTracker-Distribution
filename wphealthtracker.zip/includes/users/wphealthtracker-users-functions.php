<?php
/**
 * Class WPHealthTracker_Users_Functions - wphealthtracker-users-functions.php
 *
 * @author   Jake Evans
 * @category Admin
 * @package  Includes/Users
 * @version  0.0.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPHealthTracker_Users_Functions', false ) ) :
	/**
	 * WPHealthTracker_Users_Functions class. Here we'll do things like enqueue scripts/css, set up menus, etc.
	 */
	class WPHealthTracker_Users_Functions {



	}

endif;



